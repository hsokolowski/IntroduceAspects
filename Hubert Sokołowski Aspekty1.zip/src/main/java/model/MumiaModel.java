package model;

public class MumiaModel {
    String abc;

    public void setAbc(String abc) {
        System.out.println("M - setMumia");
        this.abc = abc;
    }
}
