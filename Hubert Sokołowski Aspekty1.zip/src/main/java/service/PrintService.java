package service;

public class PrintService {
    public static void print(){
        System.out.println("M - PrintService from service");
    }
}
