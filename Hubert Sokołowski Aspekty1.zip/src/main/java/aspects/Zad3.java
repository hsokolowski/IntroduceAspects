package aspects;

public interface Zad3 {
}
